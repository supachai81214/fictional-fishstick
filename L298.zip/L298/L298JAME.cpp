#include "L298BRJAME.h"

L298BRJAME::L298BRJAME(int in1, int in2, int ena, int in3, int in4, int enb)
    : _in1(in1), _in2(in2), _ena(ena), _in3(in3), _in4(in4), _enb(enb) { }

void L298BRJAME::begin() {
    
    pinMode(_in1, OUTPUT);
    pinMode(_in2, OUTPUT);
    pinMode(_ena, OUTPUT);
    pinMode(_in3, OUTPUT);
    pinMode(_in4, OUTPUT);
    pinMode(_enb, OUTPUT);
}


/// @brief 
/// @param dir 
/// @param speed 
/// @param frequency 
void L298BRJAME::setMotor1(bool dir, int speed, int frequency) {
    if (frequency > 0)
    {
        configureTimer1(frequency); 
    }

    if (dir)
    {
        digitalWrite(_in1, HIGH);
        digitalWrite(_in2, LOW);
        analogWrite(_ena, speed);
    }
    else
    {
        digitalWrite(_in1, LOW);
        digitalWrite(_in2, HIGH);
        analogWrite(_ena, speed);
    }
}

void L298BRJAME::setMotor2(bool dir, int speed, int frequency) {
    if (frequency > 0)
    {
        configureTimer2(frequency);
    }

    if (dir)
    {
        digitalWrite(_in3, HIGH);
        digitalWrite(_in4, LOW);
        analogWrite(_enb, speed);
    }
    else
    {
        digitalWrite(_in3, LOW);
        digitalWrite(_in4, HIGH);
        analogWrite(_enb, speed);
    }
}

void L298BRJAME ::setMotor1Speed(int speed) {
    analogWrite(_ena, speed); 
}

void L298BRJAME::setMotor2Speed(int speed) {
    analogWrite(_enb, speed); 
}

void L298BRJAME::setMotor1Frequency(int frequency) {
    configureTimer1(frequency);
}

void L298BRJAME::setMotor2Frequency(int frequency) {
    configureTimer2(frequency);
}

void L298BRJAME::configureTimer1(int frequency) {
    long prescaler = 1; 
    long topValue = 16000000 / (2 * prescaler * frequency) - 1; 

    
    if (topValue > 65535) {
        prescaler = 8; 
        topValue = 16000000 / (2 * prescaler * frequency) - 1;
    }
    if (topValue > 65535) {
        prescaler = 64; 
        topValue = 16000000 / (2 * prescaler * frequency) - 1;
    }
    if (topValue > 65535) {
        prescaler = 256; 
        topValue = 16000000 / (2 * prescaler * frequency) - 1;
    }
    if (topValue > 65535) {
        prescaler = 1024; 
        topValue = 16000000 / (2 * prescaler * frequency) - 1;
    }

    if (topValue > 65535) {
        topValue = 65535;
    }

    uint8_t prescalerBits = 0;
    if (prescaler == 1) prescalerBits = (1 << CS10);
    else if (prescaler == 8) prescalerBits = (1 << CS11);
    else if (prescaler == 64) prescalerBits = (1 << CS11) | (1 << CS10);
    else if (prescaler == 256) prescalerBits = (1 << CS12);
    else if (prescaler == 1024) prescalerBits = (1 << CS12) | (1 << CS10);

   
    TCCR1A = (1 << WGM11) | (1 << COM1B1); 
    TCCR1B = (1 << WGM13) | (1 << WGM12) | prescalerBits; 
    ICR1 = topValue; 
}

void L298BRJAME::configureTimer1(int frequency) {
    long prescaler = 1; 
    long topValue = 16000000 / (2 * prescaler * frequency) - 1; 

    if (topValue > 65535) {
        prescaler = 8; 
        topValue = 16000000 / (2 * prescaler * frequency) - 1;
    }
    if (topValue > 65535) {
        prescaler = 64; 
        topValue = 16000000 / (2 * prescaler * frequency) - 1;
    }
    if (topValue > 65535) {
        prescaler = 256; 
        topValue = 16000000 / (2 * prescaler * frequency) - 1;
    }
    if (topValue > 65535) {
        prescaler = 1024; 
        topValue = 16000000 / (2 * prescaler * frequency) - 1;
    }

    if (topValue > 65535) {
        topValue = 65535;
    }

    uint8_t prescalerBits = 0;
    if (prescaler == 1) prescalerBits = (1 << CS10);
    else if (prescaler == 8) prescalerBits = (1 << CS11);
    else if (prescaler == 64) prescalerBits = (1 << CS11) | (1 << CS10);
    else if (prescaler == 256) prescalerBits = (1 << CS12);
    else if (prescaler == 1024) prescalerBits = (1 << CS12) | (1 << CS10);

    // ใช้โหมดการทำงานเป็น Normal PWM
    TCCR1A = (1 << COM1B1);  // Non-inverting mode
    TCCR1B = prescalerBits;  // ตั้งพรีสเกลเลอร์
    ICR1 = topValue;         // กำหนดค่า TOP value
}

void L298BRJAME::configureTimer2(int frequency) {
    long prescaler = 1;
    long topValue = 16000000 / (prescaler * frequency) - 1;

    if (topValue > 255) {
        prescaler = 8;
        topValue = 16000000 / (prescaler * frequency) - 1;
    }
    if (topValue > 255) {
        prescaler = 64;
        topValue = 16000000 / (prescaler * frequency) - 1;
    }
    if (topValue > 255) {
        prescaler = 256;
        topValue = 16000000 / (prescaler * frequency) - 1;
    }
    if (topValue > 255) {
        prescaler = 1024;
        topValue = 16000000 / (prescaler * frequency) - 1;
    }

    // จำกัดค่า TOP Value ให้อยู่ในช่วง 0–255
    if (topValue > 255) topValue = 255;

    // ตั้งค่า Prescaler Bits
    uint8_t prescalerBits = 0;
    if (prescaler == 1) prescalerBits = (1 << CS20);
    else if (prescaler == 8) prescalerBits = (1 << CS21);
    else if (prescaler == 64) prescalerBits = (1 << CS21) | (1 << CS20);
    else if (prescaler == 256) prescalerBits = (1 << CS22);
    else if (prescaler == 1024) prescalerBits = (1 << CS22) | (1 << CS20);

    // ตั้งค่า Timer2 ในโหมด PWM ธรรมดา (Normal)
    TCCR2A = (1 << COM2B1);  // Non-inverting mode
    TCCR2B = prescalerBits;  // ตั้งพรีสเกลเลอร์
    OCR2A = topValue;        // กำหนดค่า TOP value
}

