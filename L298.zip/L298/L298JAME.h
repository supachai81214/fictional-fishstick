#ifndef L298JAME_H
#define L298JAME_H

#include <Arduino.h>
class L298JAME
{
    public:
      L298JAME(int in1, int in2, int ena, int in3, int in4, int enb);
    void begin();
    void setMotor1(bool dir, int speed, int frequency);
    void setMotor2(bool dir, int speed, int frequency);
    void setMotor1Speed(int speed);
    void setMotor2Speed(int speed);
    void setMotor1Frequency(int frequency);
    void setMotor2Frequency(int frequency);
    void stopMotors();
    void turnRight();
    void turnLeft();
    void backward();
    void forward();
    void Motor1speed(bool state, int speed); 
    void Motor2speed(bool state, int speed);
    void fan1SET(int speed);
    void fan2SET(int speed);    
    private:
    int _in1, _in2, _ena;
    int _in3, _in4, _enb;

    void configureTimer1(int frequency); 
    void configureTimer2(int frequency); 
};

extern L298JAME JAME;
void fan1SET(int speed);
void fan2SET(int speed);    
void Motor1set(bool state, int speed);
void Motor2set(bool state, int speed);
#endif
